<html xmlns:data="http://www.w3.org/1999/xhtml">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
    <meta content="MSHTML 6.00.2900.2627" name="GENERATOR"/>
    <style type="text/css">
        .normaltxt
        {
            COLOR: #000000;
            FONT-FAMILY: Arial, sans-serif;
            FONT-SIZE: 13px
        }

        .disclaimer
        {
            COLOR: #000000;
            FONT-FAMILY: Arial, sans-serif;
            FONT-SIZE: 13px;
            FONT-STYLE: ITALIC;
        }

        .headings
        {
            COLOR: #000000;
            FONT-FAMILY: Arial, sans-serif;
            FONT-SIZE: 15px;
            FONT-WEIGHT: bold
        }

        .mainsection
        {
            background-color: #ffffff;
            text-align: center;
        }

        body
        {
            background: none repeat scroll 0 0 #F6F6F4;
            color: #000000;
            font-family: Arial, sans-serif;
        }

        .mainContainer
        {
            padding-left: 30px;
            padding-right: 25px;
            width: 600px;
        }

        .subMain td
        {
            border-bottom: 1px solid #FFFFFF;
            border-right: 1px solid #FFFFFF;
            padding: 5px;
        }

        .footer
        {
            font-style:italic;
            font-color:#000000;
        }

        .footer a
        {
            font-color:#000000;
        }
    </style>
</head>
<body>

<table cellspacing="0" cellpadding="0" width="600px" align="center" border="0" id="Table2">
    <tr>
        <td valign="top" class="mainsection" style="">
            <table width="100%" border="0">
                <tr>
                    <td class="mainContainer">
                        <?php echo $__env->yieldContent('content'); ?>
                    </td>
                </tr>

                <tr>
                    <td class="mainContainer">

                        <br/>

                        <div align="justify" style="padding-right: 15px; padding-left: 10px; padding-top: 10px">
                            <p class="disclaimer">
                                <h5>
                                    Our Best,
                                </h5>
                                <h4>Society System</h4>

                                <a href="mailto:societysystem24@gmail.com">societysystem24@gmail.com</a>
                            </p>

                        </div>


                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>

<?php /**PATH C:\Users\lab301\Desktop\Project\society_system\resources\views/mail/base.blade.php ENDPATH**/ ?>