<html xmlns:data="http://www.w3.org/1999/xhtml">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
    <meta content="MSHTML 6.00.2900.2627" name="GENERATOR"/>
    <style type="text/css">
        .normaltxt
        {
            COLOR: #002b9f;
            FONT-FAMILY: Arial, sans-serif;
            FONT-SIZE: 13px
        }

        .disclaimer
        {
            COLOR: #989696;
            FONT-FAMILY: Arial, sans-serif;
            FONT-SIZE: 13px;
            FONT-STYLE: ITALIC;
        }

        .headings
        {
            COLOR: #002b9f;
            FONT-FAMILY: Arial, sans-serif;
            FONT-SIZE: 15px;
            FONT-WEIGHT: bold
        }

        .mainsection
        {
            background-color: #ffffff;
            text-align: center;
        }

        body
        {
            background: none repeat scroll 0 0 #F6F6F4;
            color: #002b9f;
            font-family: Arial, sans-serif;
        }

        .mainContainer
        {
            padding-left: 30px;
            padding-right: 25px;
            width: 600px;
        }

        .subMain td
        {
            border-bottom: 1px solid #FFFFFF;
            border-right: 1px solid #FFFFFF;
            padding: 5px;
        }

        .footer
        {
            font-style:italic;
            font-color:#c0c0c0;
        }

        .footer a
        {
            font-color:#002b9f;
        }
    </style>
</head>
<body>

<table cellspacing="0" cellpadding="0" width="600px" align="center" border="0" id="Table2">
    <tr>
        <td>
            <img src="<?php echo e(url('/')); ?>/assets/images/logo.png" alt="Liberty Exit Interviews"/>
        </td>
    </tr>
    <tr>
        <td valign="top" class="mainsection" style="">
            <table width="100%" border="0">
                <tr>
                    <td class="mainContainer">
                        <?php echo $__env->yieldContent('content'); ?>
                    </td>
                </tr>

                <tr>
                    <td class="mainContainer">

                        <br/>

                        <div align="justify" style="padding-right: 15px; padding-left: 10px; padding-top: 10px">
                            <p class="disclaimer">
                                Any information provided directly to business units will show trends and will not pinpoint specific respondents. For any queries please
                                contact your Human Resource Business Partner or alternatively you can contact  <a href="mailto:support@conciseflow.co.za">support@conciseflow.co.za</a>
                            </p>

                        </div>


                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td>
            <div style="border-top: 2px solid #454545; text-align: right; padding: 5px;">

            </div>
        </td>
    </tr>
</table>
</body>
</html>

<?php /**PATH C:\Users\lab301\Desktop\Project\society_system\resources\views/mail\base.blade.php ENDPATH**/ ?>