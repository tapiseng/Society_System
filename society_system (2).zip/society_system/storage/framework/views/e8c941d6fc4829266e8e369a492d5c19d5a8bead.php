
<?php $__env->startSection('content'); ?>
<div class="normaltxt" align="justify">
    <br/>
    <p class="headings">Hi,</p>

    <p><i><strong>Thank you for joining the Society System</strong></i></p>
    
    <div align="justify">
        <p>
            We'll keep you posted on the updates, news and special offers.    
        </p>

        <p>
            Have question about Society System? We'd love to help! Just hit reply:)
        </p>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mail.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lab301\Desktop\Project\society_system\resources\views/mail/user_register.blade.php ENDPATH**/ ?>