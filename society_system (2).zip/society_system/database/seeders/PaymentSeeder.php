<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PaymentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         DB::table('payments')->delete();

        DB::table('payments')->insert(array (
            0 =>
            array (
                'payment_date' => date('Y/m/d'),
            	'member_id' => 3,
            	'option_id'=> 1,
            	'service_id' => 2,
                'amount_paid' => 120,
            ),
            1 =>
            array (
                'payment_date' => date('Y/m/d'),
            	'member_id' => 1,
            	'option_id'=> 3,
            	'service_id' => 1,
                'amount_paid' => 90,
            ),
            2 =>
            array (
                'payment_date' => date('Y/m/d'),
            	'member_id' => 3,
            	'option_id'=> 2,
            	'service_id' => 1,
                'amount_paid' => 0,
            )
        ));
    }
}
