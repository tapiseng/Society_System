<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class RaceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('races')
        ->insert([
            'name'=>'African'
        ]);
        \DB::table('races')
        ->insert([
            'name'=>'Coloured'
        ]);
        \DB::table('races')
        ->insert([
            'name'=>'Indian'
        ]);
        \DB::table('races')
        ->insert([
            'name'=>'White'
        ]);
        \DB::table('races')
        ->insert([
            'name'=>'Negroid'
        ]);
    }
}
