<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	$id = 60;
        $faker = \Faker\Factory::create();
        $gender = $faker->randomElement(['male', 'female']);

        DB::table('users')->delete();

        DB::table('users')->insert(array (
            0 =>
            array (
            	'id' => 1,
                'first_name' => 'Mandy',
            	'last_name' => 'Legros',
            	'email' => 'Legros@gmail.com',
            	
                'username' => Str::random(10).'@gmail.com',
            	'password' => Hash::make('123'),
            	'members_id' => 1,
            ),
            1 =>
            array (
              'id' => 2,
                'first_name' => 'Ismael',
            	'last_name' => 'Schinner',
            	'email' => 'Schinner__@gmail.com',

            	'username' => Str::random(10).'@gmail.com',
            	'password' => Hash::make('123'),
            	'members_id' => 2,
            ),
            2 =>
            array (
                'id' => 3,
                'first_name' => 'Martina',
            	'last_name' => 'Armstrong',
            	'email' => 'Martina__@gmail.com',

            	'username' => Str::random(10).'@gmail.com',
            	'password' => Hash::make('123'),
            	'members_id' => 3,
            ),
            17 =>
            array (
                'id' => 4,
                'first_name' => 'Orlo',
            	'last_name' => 'Bashirian',
            	'email' => $faker->email,

            	'username' => 'admin@gmail.com',
                
            	'password' => '$2y$10$fpieoefOgZAf43eRxq/ikexjX3RB4kRwofXXTpwoO4oEh71VXy.PO',
            	'members_id' => 4,
            ),
        ));

    }
}
