<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class MemberSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
    	$id = 60;
        $faker = \Faker\Factory::create();
        $gender = $faker->randomElement(['male', 'female']);

        DB::table('members')->delete();

        DB::table('members')->insert(array (
            0 =>
            array (
            	'id' => 1,
                'first_name' => 'Mandy',
            	'last_name' => 'Legros',
            	'email' => 'Legros@gmail.com',
            	'cell_phone' => $faker->phoneNumber,
            	

                'start_date' => date('Y/m/d'),
            	'id_number' => $id,
            	'race_cat'=> 1,
            	'gender_cat' => 1,
            ),
            1 =>
            array (
              'id' => 2,
                'first_name' => 'Ismael',
            	'last_name' => 'Schinner',
            	'email' => 'Schinner__@gmail.com',
            	'cell_phone' => $faker->phoneNumber,
            	

                'start_date' => date('Y/m/d'),
            	'id_number' => '8565232356895',
            	'race_cat'=> 3,
            	'gender_cat' => 1,
            ),
            2 =>
            array (
                'id' => 3,
                'first_name' => 'Martina',
            	'last_name' => 'Armstrong',
            	'email' => 'Martina__@gmail.com',
            	'cell_phone' => $faker->phoneNumber,
            	

                'start_date' => date('Y/m/d'),
            	'id_number' => '0015232356895',
            	'race_cat'=> 2,
            	'gender_cat' => 1,
            ),
            17 =>
            array (
                'id' => 4,
                'first_name' => 'Orlo',
            	'last_name' => 'Bashirian',
            	'email' => $faker->email,
            	'cell_phone' => $faker->phoneNumber,


                'start_date' => date('Y/m/d'),
            	'id_number' => '9565232356895',
            	'race_cat'=> 1,
            	'gender_cat' => 2,
            ),
        ));

    }
}
