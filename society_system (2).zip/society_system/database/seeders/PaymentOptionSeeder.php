<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PaymentOptionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \DB::table('payment_options')
        ->insert([
            'name'=>'Cash'
        ]);
        \DB::table('payment_options')
        ->insert([
            'name'=>'Checks'
        ]);

        \DB::table('payment_options')
        ->insert([
            'name'=>'Debit cards'
        ]);
        \DB::table('payment_options')
        ->insert([
            'name'=>'Credit cards'
        ]);

         \DB::table('payment_options')
        ->insert([
            'name'=>'Mobile payment'
        ]);
        \DB::table('payment_options')
        ->insert([
            'name'=>'Electronic bank transfer'
        ]);
    }
}
