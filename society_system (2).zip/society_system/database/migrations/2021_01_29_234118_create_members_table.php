<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMembersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('members', function (Blueprint $table) {
            $table->bigIncrements('id');

            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('email')->unique();
            $table->string('cell_phone');
            $table->smallInteger('active')->unsigned()->default(1);

            $table->date('start_date')->nullable();
            $table->string('id_number')->unique();
            $table->unsignedBigInteger('race_cat');
            $table->foreign('race_cat')->references('id')->on('races')->onDelete('cascade');

            $table->unsignedBigInteger('gender_cat');
            $table->foreign('gender_cat')->references('id')->on('genders')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        Schema::dropIfExists('members');
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}
