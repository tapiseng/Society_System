import React, {Component} from 'react';
import Header from "./portal/Header";
import Nav from "./portal/Nav";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Dashboard from "./portal/Dashboard";

import UserTable from "./portal/UserTable";
import PaymentTable from "./portal/PaymentTable";
import MemberTable from "./portal/MemberTable";
import axios from 'axios'


export default class Portal extends Component{
    


constructor(props) {
        super(props)
        this.state = {
            is_logged_in: true,
            username: null,
            password: null,
            user_role:null,
            fullNames: null
        }

        this.onChange = this.onChange.bind(this)
        this.login = this.login.bind(this)
        this.sleep = this.sleep.bind(this)
    }

    componentDidMount() {
        axios.
            get('/getUserDetails').then(res=>{
                console.clear()
                console.log(res.data)
                this.setState({
                    user_role: res.data.user_role,
                    fullNames: res.data.fullNames
                })
        })

        var count = 0;
    }

    login(event){
        event.preventDefault()

        axios.
            post('/signin',
            {
                username: this.state.username,
                password: this.state.password
            },
            {
                headers: {'Content-Type': 'aplication/json'}
            }).
            then(res =>
        {
            if(res.data.response===true){
                console.log("Hello");
                this.sleep(7000);
                console.log("World!");
                this.setState({
                    is_logged_in: true
                })
            }
            console.log(res.data)
        })

    }
    sleep(milliseconds) {
        const date = Date.now();
        let currentDate = null;
        do {
            currentDate = Date.now();
        } while (currentDate - date < milliseconds);
    }
    onChange(e){
        this.setState({
            [e.target.name] : e.target.value
        })
    }



    render() {

        return (
            <Router>
                <Switch>
                        <div class="wrapper">

                        <Header fullNames={this.state.fullNames}/>

                        <div className="page-wrap">
                            <div class="app-sidebar colored">
                                <Nav user_role={this.state.user_role}/>
                            </div>

                            
                             <div className="main-content">
                                <div className="container-fluid">

                        {(this.state.user_role===1 || this.state.user_role===2) &&(
                            <Route exact path='/' component={Dashboard}/>
                        )}

                        {(this.state.user_role===1 || this.state.user_role===2) &&(
                            <Route exact path='/portal' component={Dashboard} />
                        )}

                        {(this.state.user_role===1 || this.state.user_role===2) &&(
                            <Route exact path='/user_management' component={UserTable} />
                        )}


                        {(this.state.user_role===1 || this.state.user_role===2) &&(
                            <Route exact path='/organization_members' component={MemberTable} />
                        )}

                        {(this.state.user_role===1 || this.state.user_role===2) &&(
                            <Route exact path='/payment_management' component={PaymentTable} />
                        )}

                                      
                                </div>
                            </div>
                        </div>           
                                
                        </div>
                </Switch>
    </Router>
        );
    }
}


// export  default Portal;
if (document.getElementById('root')) {
    ReactDOM.render(<Portal />, document.getElementById('root'));
}
