import React, {Component} from 'react'

class Dashboard extends Component{
    constructor(props) {
        super(props)
        this.state= {


        }
    
    }

    componentDidMount() {
        
    }
   
    
    render() {


        return (
          <div>
          <div className="page-header">

          </div>
            <div className="row">
                            <div className="col-md-12">
                                <div className="card">
                                    <div className="card-header">
                                        <h3>Data Table</h3>
                                    </div>

                                    <div className="card-body">
                                        
                                    </div>

                                </div>
                            </div>
                        </div>
        </div>
        )
    }
}

export default Dashboard
