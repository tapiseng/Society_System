import React, {Component} from 'react';
import axios from 'axios'

class Header extends Component {
    constructor(props) {
        super(props)

        this.state={

        }


    }

    me(){
        alert('lllll')
    }
    logout(){
       console.clear()
        console.log('Logout')
        // axios.
        //     get('/logout', { headers: {'Content-Type': 'aplication/json'}}).then(res =>{
        //         alert('logout')
        // })
    }

    render() {

        return (

            <header className="header-top" header-theme="light">
                <div className="container-fluid">
                    <div className="d-flex justify-content-between">
                        <div className="top-menu d-flex align-items-center">
                          <button type="button" className="btn-icon mobile-nav-toggle d-lg-none"><span></span></button>
                        </div>

                        <div className="top-menu d-flex align-items-center">
                    <span className="padding_right">{this.props.fullNames}</span> 
                            <div className="dropdown">

                                <a className="dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img className="avatar" src="assets/images/avatars/1.jpg"/></a>
                                <div className="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
         
                                    <a className="dropdown-item" href="/logout"><i className="ik ik-power dropdown-icon"></i> Logout
                                    </a>
                            </div>

                            </div>

                        </div>
                    </div>
                </div>
            </header>
        );
    }
}
export default Header;
