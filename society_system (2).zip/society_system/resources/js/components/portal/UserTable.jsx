import React, {Component} from 'react'

class UserTable extends Component{
    constructor(props) {
        super(props)
        this.state= {
        items: [],
        show_table: 0,

        //User Form Varibles
        first_name: '',
        last_name: '',
        email: '',
        username: '',
        password: '',
        active: '',
        role_id: null,
        user_id: null,
        //
        alert_message: [],
        members_id: null,
        roles: [],

        };
    
    this.handleUpdateUsers = this.handleUpdateUsers.bind(this);
    this.handleChangeInfo = this.handleChangeInfo.bind(this);
    this.onChange = this.onChange.bind(this);
    this.cancel = this.cancel.bind(this);
    
    this.handleSubmit = this.handleSubmit.bind(this);
    this.searchMember = this.searchMember.bind(this);
    this.getRoles = this.getRoles.bind(this);
    }

    getRoles() {
        axios.
        post('/user_role',
            {},
            {headers: {'Content-Type': 'application/json'}}).then(res=>{
            this.setState({
                roles: res.data.userRole,
            })
        })
    }

    searchMember()
    {
         axios.post('/get_member_detail', {
         email: this.state.email
         },{headers: {'Content-Type': 'aplication/json'}}).then(response => {

            this.setState({
                first_name: response.data[0].first_name,
                last_name: response.data[0].last_name,
                email: response.data[0].email,
                members_id: response.data[0].member_id,
            })
        })
    }

    componentWillMount() {
        this.getAllUsers();
        this.getRoles();
    }

      handleSubmit(e) {

        e.preventDefault();
        axios.post('/update_user_record', {

             id: this.state.user_id, 
             role_id: this.state.role_id,
             first_name: this.state.first_name,
             last_name: this.state.last_name,
             email: this.state.email,
             username: this.state.username,
             active: this.state.active,
             password: this.state.password, 
             members_id: this.state.members_id,
        })
            .then(response => {
                console.clear()
                // set state: Success Message
                this.setState({ 
                alert_message:"success",
                });

                this.setState({
                   first_name: '',
                   last_name: '',
                   email: '',
                   username: '',
                   password: '',
                   active: '',
                   role_id: 0,
                   user_id: 0,
                   members_id: 0,
                });
                    this.getAllUsers();
            }). catch(error=> {
            this.setState({alert_message: "error"});
        });
    }


        getAllUsers()
        {
        axios.
        post('/system_user', {headers: {'Content-Type': 'application/json'}}).then(res=>{
            this.setState({
                items: res.data.data
            })
        })
    }

 cancel(){
        this.setState(
            {
                show_table: 0,
                alert_message: [],
            }, ()=>{
                this.setState(
                    {
                        first_name: '',
                        last_name: '',
                        email: '',
                        username: '',
                        password: '',
                        active: '',
                        role_id: 0,
                        user_id: 0,
                        members_id: 0,
                        alert_message: []
                    })
            })
    }


 handleUpdateUsers( user_id, show_state_id, e ) {

        axios.post('/edit_user_info', {id: user_id},{headers: {'Content-Type': 'aplication/json'}}).then(response => {
            
            this.setState({
            user_id: response.data[0].id, 
             role_id: response.data[0].role_id,
             first_name: response.data[0].first_name,
             last_name: response.data[0].last_name,
             email: response.data[0].email,
             username: response.data[0].username,
             active: response.data[0].active, 
                password: response.data[0].password, 
                members_id: response.data[0].members_id,
            },() => {               
                 this.handleChangeInfo(show_state_id);
            })
        })
    }

    

    handleChangeInfo(id) {
        this.setState({
            show_table: id,
        },() => {
            /* this.openModal()*/
        });
    }

onChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
   
    
    render() {
        return (
          <div>
            <div className="row">
                            <div className="col-md-12">
                                <div className="card">



                            {(() => {
                                if (this.state.show_table == 0) {
                                    return (
                                    <div>
                                    <div className="card-header justify-content-between">
                                        <h3>Active Users</h3>

                    <button className="btn btn-light"
                        onClick={this.handleChangeInfo.bind(this, 1)}
                    >Add user</button>

                                    </div>

                                    <div className="card-body">
                                    <div className="dt-responsive">
                                        <table id="data_table" className="simpletable"
                                                   class="table table-striped table-bordered ">
                                            <thead>
                                                <tr>
                                                    <th>First name</th>
                                                    <th>Last Name</th>
                                                    <th>Email</th>
                                               
                                                    <th>User Roles</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            { this.state.items.map((item, index)=>(
                                                <tr>
                                            <td>{item.first_name}</td>
                                             <td>{item.last_name}</td>
                                                <td>{item.email}</td>
                                               
                                                <td>{item.role_name}</td>


                        <td>
                            <div className="table-actions text-center">         
                                <a 
                onClick={this.handleUpdateUsers.bind(this, item.id, 2)}
                                ><i className="ik ik-edit-2"></i>
                                </a>

                             </div>
                        </td>

                                                </tr>
                                            ))}

                                            </tbody>
                                        </table>
                                    </div>
                                    </div>
                                    </div>
                             )
                            } else if (this.state.show_table == 1 || this.state.show_table == 2) {
                                    return (
                                    <form onSubmit={this.handleSubmit}>
                                    <div>

        <div className="row">
            <div className="col-md-12">

                {this.state.alert_message == "success" ?
                <div className="alert alert-success" role="alert">User Updated
                  successfully.</div> : null}
                  {this.state.alert_message == "error" ?
                 <div className="alert alert-danger" role="alert">
                 Something went wrong. Please contact administrator.
                 </div> : null}
            </div>
        </div>

                                    <div className="card-header justify-content-between">
                                    
                                    {(() => {
                                if (this.state.show_table == 1) {
                                    return (
                                        <h3>Add User</h3>
                                          )
                            } else if (this.state.show_table == 2) {
                                    return (
                                        <h3>Update User</h3>
                                         )
                                }
                            })()}


                                        <button className="btn btn-light"
                                        onClick={this.cancel}
                                        >Cancel</button>
                                    </div>
                                    <div className="card-body">


            <div className="row">
                <div className="col-md-6">
                    <div className="form-group">
                        <label for="exampleInputName1">User email</label>
                        <div className="input-group input-group-button">
                        <input type="text" name="email" class="form-control" 
                        onChange={this.onChange.bind(this)} required
                        value={this.state.email}
                        />
                        <div className="input-group-append">
                            <button class="btn btn-primary" type="button"
                                    onClick={this.searchMember} 
                        >Verify</button>
                            </div>
                        </div>
                    </div>
                </div>       
            </div>


             <div className="row">
        <div className="col-md-12">

        {this.state.members_id != null ?
            <div className="alert alert-info" role="alert">
            <strong>
                Memeber name: {this.state.first_name + ' ' + this.state.last_name }, please complete details below
            </strong>
            </div> : null
        }
        </div>
        </div>



                             <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">First name</label>
                                    <input name="first_name" type="text" required  
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.first_name}
                                    />
                                </div>
                                </div>
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Last name</label>
                                    <input name="last_name" type="text" 
                                    className="form-control" required 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.last_name}
                                    />
                                </div>
                                </div>
                            </div>


                              <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                        <label for="exampleInputName1">Status</label>
 <select className="form-control select2 select2-hidden-accessible" 
 name="active"
onChange={this.onChange.bind(this)}
        value={this.state.active} required 
        data-select2-id="1" tabIndex="-1" aria-hidden="true">

        <option></option>
        <option value="1" data-select2-id="3">Active</option>
        <option value="0" data-select2-id="32">Not Active</option>
</select>

                                </div>
                                </div>

                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Role</label>                               

        <select name="role_id" required 
            className="form-control select2 select2-hidden-accessible"
            onChange={this.onChange.bind(this)}>
            <option>--Select role</option>
            { this.state.roles.map((item,index)=> (
            <option value={item.id} key={index} selected={item.id == this.state.role_id}>{item.name}
            </option>
            ))}
        </select>

                                </div>
                                </div>
                            </div>




                            <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Username</label>
                                    <input name="username" required type="text" 
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.username}
                                    />
                                </div>
                                </div>
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Password</label>
                                    <input name="password" type="password" 
                                    className="form-control" required 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.password}
                                    />
                                </div>
                                </div>
                            </div>

                    <button type="submit" className="btn btn-primary mr-2">Submit</button>

                    <button className="btn btn-light"
                        onClick={this.cancel}
                    >Cancel</button>

                                    </div>
                                    </div>
                        </form>            
                        )
                                }
                            })()}





                                </div>
                            </div>
                        </div>
        </div>
        )
    }
}

export default UserTable
