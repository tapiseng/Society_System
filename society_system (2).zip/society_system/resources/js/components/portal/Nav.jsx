import React, {Component} from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
class Nav extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user_role: this.props.user_role
        }

        this.onChangeNav = this.onChangeNav.bind(this)
    }

    componentWillReceiveProps(props, nextContext) {
        this.setState({
            user_role: props.user_role
        })
    }

    componentDidMount() {
        this.setState({
            nav: window.location.pathname
        })


    }

    onChangeNav(e){
    this.setState({
        [e.target.id]: 'mm-active'
    })
    }

    render() {


        return (
            <div>
                <div className="sidebar-header">
                        <a className="header-brand" href="index.html">
                            <div className="logo-img">
                                
                            </div>
                            <span className="text"></span>
                        </a>
                        <button type="button" className="nav-toggle"><i data-toggle="expanded" className="ik ik-toggle-right toggle-icon"></i></button>
                        <button id="sidebarClose" className="nav-close"><i class="ik ik-x"></i></button>
                    </div>

                <div className="sidebar-content">
                    <div className="nav-container">
                         <nav id="main-menu-navigation" className="navigation-main">

                             <div className="nav-lavel">Navigation</div>

                            {(this.state.user_role===1 || this.state.user_role===2) &&(
                             <div className="nav-item active">
                                    <Link to={'/portal'}><i className="ik ik-bar-chart-2"></i><span>Dashboard</span></Link>
                                </div>
                               )}

                                {(this.state.user_role===1 || this.state.user_role===2) &&(
                                 <div className="nav-item">
                                    <Link to={'/user_management'}><i className="ik ik-users"></i><span>Users</span></Link>



                                </div>
                                )}

                                {(this.state.user_role===1 || this.state.user_role===2) &&(
                                 <div className="nav-item">
                                    <Link to={'/organization_members'}><i className="ik ik-edit"></i><span> Members</span></Link>
                                </div>
                                )}

                                {(this.state.user_role===1 || this.state.user_role===2) &&(
                                <div className="nav-item">
                                    <Link to="payment_management"><i class="ik ik-file-text"></i><span>Payments</span></Link>
                                </div>
                                )}

                                 
                                <div className="nav-item has-sub">
                                    <a href="#">
                                    <i className="ik ik-pie-chart"></i><span>Reports</span>
                                    </a>                                   
                                </div>

                                 <div className="nav-item">
                                    <a href="#"><i class="ik ik-calendar"></i><span>Calendar</span></a>
                                </div>

                                <div className="nav-item">
                                    <a href="javascript:void(0)"><i class="ik ik-help-circle"></i><span>Help and Support</span></a>
                                </div>


                         </nav>
                    </div>
                </div>

        </div>
        );
    }
}
export default Nav;
