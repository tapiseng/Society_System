import React, {Component} from 'react'

class MemberTable extends Component{
    constructor(props) {
        super(props)
        this.state= {
        items: [],
        show_table: 0,
        alert_message: [],

        //User Form Varibles
        member_id: '',
        first_name: '',
        last_name: '',
        email: '',
        cell_phone: '',
        active: '',
        start_date: '',
        id_number: '',
        gender_cat: null,
        race_cat: null,
        genders: [],
        races: [],
        };
    
    this.handleUpdateMembers = this.handleUpdateMembers.bind(this);
    this.handleChangeInfo = this.handleChangeInfo.bind(this);
    this.onChange = this.onChange.bind(this);
    this.cancel = this.cancel.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);

    this.getGenders = this.getGenders.bind(this);
    this.getRaces = this.getRaces.bind(this);
    }

    getGenders() {
        axios.
        post('/get_genders',
            {},
            {headers: {'Content-Type': 'application/json'}}).then(res=>{
            this.setState({
                genders: res.data.gender,
            })
        })
    }

    getRaces() {
        axios.
        post('/get_races',
            {},
            {headers: {'Content-Type': 'application/json'}}).then(res=>{
            this.setState({
                races: res.data.race,
            })
        })
    }

    componentWillMount() {
        this.getAllMembers();
        this.getGenders();
        this.getRaces();
    }

    cancel(){
        this.setState(
            {
                show_table: 0,
                alert_message: [],
            }, ()=>{
                this.setState(
                    {
                        member_id: '',
                        first_name: '',
                        last_name: '',
                        email: '',
                        cell_phone: '',
                        active: '',
                        start_date: '',
                        id_number: '',
                        gender_cat: 0,
                        race_cat: 0,
                        alert_message: [],
                    })
            })
    }


     handleSubmit(e) {

        e.preventDefault();
        axios.post('/update_Member_record', {
             id: this.state.member_id, 
             first_name: this.state.first_name,
             last_name: this.state.last_name,
             email: this.state.email,

             cell_phone: this.state.cell_phone,
             active: this.state.active,
             start_date: this.state.start_date,
             id_number: this.state.id_number,

             gender_cat: this.state.gender_cat,
             race_cat: this.state.race_cat,
        })
            .then(response => {
                console.clear()
                // set state: Success Message
                this.setState({ 
                alert_message:"success",
                });

                this.setState({
                        member_id: '',
                        first_name: '',
                        last_name: '',
                        email: '',

                        cell_phone: '',
                        active: '',
                        start_date: '',
                        id_number: '',

                        gender_cat: 0,
                        race_cat: 0,
                        //alert_message: [],
                });
                    this.getAllMembers();
            }). catch(error=> {
            this.setState({alert_message: "error"});
        });
    }


     getAllMembers()
        {
        axios.
        post('/get_members', {headers: {'Content-Type': 'application/json'}}).then(res=>{
            this.setState({
                items: res.data.data
            })
        })
    }


 handleUpdateMembers( member_id, show_state_id, e ) {
        axios.post('/edit_member_info', {id: member_id},{headers: {'Content-Type': 'aplication/json'}}).then(response => {
     
            this.setState({
                member_id: response.data[0].id, 
                first_name: response.data[0].first_name,
                last_name: response.data[0].last_name,
                email: response.data[0].email,
                cell_phone: response.data[0].cell_phone,

                active: response.data[0].active,
                start_date: response.data[0].start_date, 
                id_number: response.data[0].id_number,
                gender_cat: response.data[0].gender_cat,
                race_cat: response.data[0].race_cat,
            },() => {               
                 this.handleChangeInfo(show_state_id);
            })
        })
    }

    

    handleChangeInfo(id) {
        this.setState({
            show_table: id,
        },() => {
            /* this.openModal()*/
        });
    }

    onChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
   
    
    render() {
        return (
          <div>
            <div className="row">
                            <div className="col-md-12">
                                <div className="card">

                            {(() => {
                                if (this.state.show_table == 0) {
                                    return (
                                    <div>
                                    <div className="card-header justify-content-between">
                                        <h3>Members</h3>

                    <button className="btn btn-light"
                        onClick={this.handleChangeInfo.bind(this, 1)}
                    >Add member</button>

                                    </div>

                                    <div className="card-body">
                                    <div className="dt-responsive">
                                        <table id="data_table" className="simpletable"
                                                   class="table table-striped table-bordered ">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Phone Nr</th>
                                                    <th>Gender</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            { this.state.items.map((item, index)=>(
                                                <tr>
                        <td>{item.first_name + ' ' + item.last_name }</td>
                                                <td>{item.email}</td>
                                                <td>{item.cell_phone}</td>
                                                <td>{item.gender_name}</td>


                        <td>
                            <div className="table-actions text-center">

                                <a
                onClick={this.handleUpdateMembers.bind(this, item.id, 2)}
                                ><i className="ik ik-edit-2"></i></a>

                             </div>
                        </td>

                                                </tr>
                                            ))}

                                            </tbody>
                                        </table>
                                    </div>
                                    </div>
                                    </div>
                             )
                            } else if (this.state.show_table == 1 || this.state.show_table == 2) {
                                    return (


                                     <form onSubmit={this.handleSubmit}>
                                    <div>

        <div className="row">
            <div className="col-md-12">

                {this.state.alert_message == "success" ?
                <div className="alert alert-success" role="alert">User Updated
                  successfully.</div> : null}
                  {this.state.alert_message == "error" ?
                 <div className="alert alert-danger" role="alert">
                 Something went wrong. Please contact administrator.
                 </div> : null}
            </div>
        </div>

                                    <div className="card-header justify-content-between">

                                         {(() => {
                                if (this.state.show_table == 1) {
                                    return (
                                        <h3>Add member</h3>
                                          )
                            } else if (this.state.show_table == 2) {
                                    return (
                                        <h3>Update member</h3>
                                         )
                                }
                            })()}

                                        <button className="btn btn-light"
                                        onClick={this.cancel}
                                        >Cancel</button>
                                    </div>
                                    <div className="card-body">

                             <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">First name</label>
                                    <input name="first_name" type="text" 
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.first_name}
                                    />
                                </div>
                                </div>
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Last name</label>
                                    <input name="last_name" type="text" 
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.last_name}
                                    />
                                </div>
                                </div>
                            </div>


                            <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Email</label>
                                    <input name="email" type="email" 
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.email}
                                    />
                                </div>
                                </div>
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Gender</label>


        <select name="gender_cat" required 
            className="form-control select2 select2-hidden-accessible"
            onChange={this.onChange.bind(this)}>
            <option>--Select gender</option>
            { this.state.genders.map((item,index)=> (
            <option value={item.id} key={index} selected={item.id == this.state.gender_cat}>{item.name}
            </option>
            ))}
        </select>


                                </div>
                                </div>
                            </div>


                            <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Tel Nr</label>
                                    <input name="cell_phone" type="text" 
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.cell_phone}
                                    />
                                </div>
                                </div>
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Race</label>
                                    
  

    <select name="race_cat" required 
            className="form-control select2 select2-hidden-accessible"
            onChange={this.onChange.bind(this)}>
            <option>--Select gender</option>
            { this.state.races.map((item,index)=> (
            <option value={item.id} key={index} selected={item.id == this.state.race_cat}>{item.name}
            </option>
            ))}
        </select>


                                </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">ID number</label>
                                    <input name="id_number" type="text" 
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.id_number}
                                    />
                                </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Start date</label>
                                    <input name="start_date" type="date" 
                                    className="form-control" 
                                    onChange={this.onChange.bind(this)}
                                    value={this.state.start_date}
                                    />
                                </div>
                                </div>
                                <div className="col-md-6">
                                <div className="form-group">
                                    <label for="exampleInputName1">Status</label>


                <select className="form-control select2 select2-hidden-accessible" name="active"
                onChange={this.onChange.bind(this)}
                    value={this.state.active} required 
                    data-select2-id="1" tabIndex="-1" aria-hidden="true">
                        <option></option>
                    <option value="1" data-select2-id="1">Active</option>
                    <option value="0" data-select2-id="0">Not Active</option>
                </select>

                                </div>
                                </div>
                            </div>

                    <button type="submit" className="btn btn-primary mr-2">Submit</button>
                    <button className="btn btn-light"
                    onClick={this.cancel}>Cancel</button>
                            

                                    </div>
                                    </div>
                 </form>


                                        )
                                    }
                                else if (this.state.show_table == 3) {
                                    return (
                                     <div>
                                    <div className="card-header">
                                        <h3>User Details</h3>
                                    </div>
                                    <div className="card-body">

                                    </div>
                                    </div>
         )
                                }
                            })()}



                                </div>
                            </div>
                        </div>
        </div>
        )
    }
}

export default MemberTable
