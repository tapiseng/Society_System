import React, {Component} from 'react';
import ReactDOM from "react-dom";


export default class Login extends Component {
    constructor(props) {
        super(props)
        this.state ={
            hide_login_loader: true,
            username: null,
            password: null,
            response_msg: '',
            is_authenticated: false,
            login_response: false
        }

        this.loginSubmit = this.loginSubmit.bind(this)
        this.onChange = this.onChange.bind(this)
        this.sleep = this.sleep.bind(this)
    }
    sleep(milliseconds) {
        const date = Date.now();
        let currentDate = null;
        do {
            currentDate = Date.now();
        } while (currentDate - date < milliseconds);
    }
    onChange(e){
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    loginSubmit(e){
        e.preventDefault()
        this.setState({
            hide_login_loader: false,
            login_response:false
        })
        console.log('Login submit method')
        axios.
        post('/signin',
            {
                username: this.state.username,
                password: this.state.password
            },
            {
                headers: {'Content-Type': 'aplication/json'}
            }).
        then(res =>
        {
            this.setState({
                login_response: true,
                response_msg: res.data.message,
                hide_login_loader: true
            }, ()=>{

                if(res.data.response===true){

                    this.setState({
                        is_authenticated: true

                    }, ()=>{
                        console.log("Hello")
                        // this.sleep(3000)
                        console.log("World!");
                        location.replace('/')
                    })

                }else{
                    this.setState({
                        is_authenticated: false
                    })
                }
            })
            console.log(res.data)
        })
    }
    render() {

        return (
            <div className="authentication-form mx-auto">
                <div className="text-center">
                    
                </div>
              
                {this.state.login_response ? (
                           <div>
                               {this.state.is_authenticated ?(
                               <div className="alert alert-success" role="alert">
                                   {this.state.response_msg}
                               </div>
                           ):(
                               <div className="alert alert-danger" role="alert">
                                   {this.state.response_msg}
                               </div>
                           )}
                           </div>
                    ):(<div></div>)}

                <br/>
                <h3 className="text-center">Sign In to Society System</h3>
                <p>Happy to see you again!</p>
                <form onSubmit={this.loginSubmit.bind(this)}>
                    <div className="form-group">
                        <input type="email"
                               className="form-control"
                               placeholder="Email"
                               required=""
                               name="username"
                               onChange={this.onChange.bind(this)}
                               value={this.state.username} />
                            <i className="ik ik-user"></i>
                    </div>
                    <div className="form-group">
                        <input type="password"
                               className="form-control"
                               placeholder="Password"
                               required="true"
                               name="password"
                               onChange={this.onChange.bind(this)}
                               value={this.state.password} />
                            <i className="ik ik-lock"></i>
                    </div>

                    <div className="row">
                        <div className="col text-left">
                            <label className="custom-control custom-checkbox">
                                <input type="checkbox"
                                       className="custom-control-input"
                                       id="item_checkbox"
                                       name="item_checkbox"

                                       value="" />
                                    <span className="custom-control-label">&nbsp;Remember Me</span>
                            </label>
                        </div>

                        <div className="col text-right"  disabled="true">
                            <a href="#">Forgot Password ?</a>
                        </div>
                    </div>
                    <div className="sign-btn text-center">


                            <button className="btn btn-secondary" type="submit" name="submit">

                                <span className="spinner-border spinner-border-sm"  hidden={this.state.hide_login_loader}></span>
                                Sign In
                            </button>




                    </div>
                </form>

            </div>
        );
    }
}

// export  default Portal;
if (document.getElementById('login_root')) {
    ReactDOM.render(<Login />, document.getElementById('login_root'));
}

