<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserRolesController;
use App\Http\Controllers\MailController;
use App\Http\Controllers\MemberController; 
use App\Http\Controllers\PaymentController; 

use App\Http\Controllers\PaymentOptionController;
use App\Http\Controllers\RaceController;
use App\Http\Controllers\GenderController;
use App\Http\Controllers\ServiceController;

//Home Controller
Route::get('/signin', [HomeController::class, 'signin'])->name('signin');
Route::get('/', [HomeController::class, 'portal'])->middleware('auth');
Route::get('/portal',  [HomeController::class, 'portal'])->middleware('auth');
Route::get('/user_management',  [HomeController::class, 'portal'])->middleware('auth');
Route::get('/payment_management',  [HomeController::class, 'portal'])->middleware('auth');
Route::get('/organization_members',  [HomeController::class, 'portal'])->middleware('auth');
//Login
Route::post('auth', [AuthController::class, 'auth']);
Route::post('signin', [AuthController::class, 'login']);
Route::get('logout', [AuthController::class, 'logout'])->middleware('auth');
//User role management
Route::post('/system_user', [UserRolesController::class, 'getUsersInfo'])->middleware('auth');
Route::get('/getUserDetails', [UserRolesController::class, 'getUserRole'])->middleware('auth');
//
Route::post('/edit_user_info', [UserRolesController::class, 'edit'])->middleware('auth');
Route::post('/update_user_record', [UserRolesController::class, 'update'])->middleware('auth');


//Emails Management Testing
Route::get('sendconfirm_regi', [ MailController::class, 'confirm_regi' ]);

//Members Controller
Route::post('/get_members', [MemberController::class, 'index'])->middleware('auth');
Route::post('/edit_member_info', [MemberController::class, 'edit'])->middleware('auth');
Route::post('/update_Member_record', [MemberController::class, 'update'])->middleware('auth');

Route::post('/get_member_detail', [MemberController::class, 'show'])->middleware('auth');

//Payments controller
Route::post('/get_payments', [PaymentController::class, 'index'])->middleware('auth');
Route::post('/edit_payment_info', [PaymentController::class, 'edit'])->middleware('auth'); 
Route::post('/update_payment_record', [PaymentController::class, 'update'])->middleware('auth');
//populate dropdown
Route::post('/get_races', [RaceController::class, 'index'])->middleware('auth');
Route::post('/get_genders', [GenderController::class, 'index'])->middleware('auth');
Route::post('/get_services', [ServiceController::class, 'index'])->middleware('auth');
Route::post('/get_payment_options', [PaymentOptionController::class, 'index'])->middleware('auth');
Route::post('/user_role', [UserRolesController::class, 'getRoles'])->middleware('auth');