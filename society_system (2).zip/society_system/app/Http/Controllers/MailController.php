<?php
namespace App\Http\Controllers;
use App\Mail\UserRegisterMail;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Mail;

class MailController extends Controller
{
    public function confirm_regi()
    {
        $member_name = 'Mosese Tapiseng';
        $root_path = url('/');
        
        Mail::to('mosesetmt@gmail.com')->send(new UserRegisterMail());
        return 'Email was sent';
    }

}
