<?php
namespace App\Http\Controllers;
use App\Models\Payment;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function index()
    {
        $payment_filter_clause = null;
        $searchValue = null;
        $totalRecords = Payment::buildPaymentQuery(Payment::$filteredTotal_number, null, null);
        ## Total number of record with filtering
        $totalRecordwithFilter = Payment::buildPaymentQuery(Payment::$filteredTotal_number, $searchValue, null);
        ## Fetch records
        $data = Payment::buildPaymentQuery(Payment::$strPaymentQuery, $searchValue, $payment_filter_clause);

        foreach($totalRecordwithFilter as $value){
            $totalRecordwithFilter = $value->allcount;
        }
        return array
        (
            'error' => false,
            'response' => true,
            'data'=>$data
        );
    }

    public function edit(Request $request)
    {
        $searchValue = null;
        $payment_filter_clause = '';
        $payment_filter_clause .= 
        " AND p.id = ". $request->id;
        $payment_record = Payment::buildPaymentQuery(Payment::
        $strPaymentQuery, $searchValue, $payment_filter_clause);
        return $payment_record;
    }
    
    public function update(Request $request)
    {
        if((int)$request->id > 0){
            $payment = Payment::find((int)$request->id);
        }else{
            $payment = new Payment;      
        }
        $payment->payment_date = $request->payment_date;
        $payment->member_id = $request->member_id;
        $payment->option_id = $request->option_id;
        $payment->service_id = $request->service_id;
        $payment->amount_paid = $request->amount_paid;     
        $payment->save();
        return $payment;
    }
}
