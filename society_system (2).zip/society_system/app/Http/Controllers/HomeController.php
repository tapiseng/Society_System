<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Auth;

class HomeController extends Controller
{
    public function portal()
    {
       return view('portal');
   	}
   	public function signin()
   	{ 
       return view('login');
   	}
}
