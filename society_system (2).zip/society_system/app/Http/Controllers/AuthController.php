<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Auth;
use App\User;
use Session;

class AuthController extends Controller
{
    public function logout()
    {
        Session::flush ();
        Auth::logout ();
        return redirect()->back();
    }

    public function login(Request $request)
    {
        if (Auth::attempt ( array (
            'email' => $request->get ( 'username' ),
            'password' => $request->get ( 'password' )
            ))) {
            session ( [
                'user_id' => auth::user()->id
            ] );
            return array
            (
                'error'=>false,
                'response'=>true,
                'message'=>'Welcome to Society System'
            );
        } else {
            return array
            (
                'error'=>false,
                'response'=>false,
                'message'=>'Invalid Username or Password'
            );
        } 
    } 
}
