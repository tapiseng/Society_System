<?php
namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Role;
use App\Models\UserRole;
use Auth;

class UserRolesController extends Controller
{
    protected $mail;

    public function __construct(MailController $mail)
    {
        $this->middleware('auth');
        $this->mail = $mail;
    }

    public function getUserRole(){
        $userrole_id = UserRole::where('user_id',auth::user()->id)->pluck('role_id')[0];   
        if((int)$userrole_id===1){
            $fullNames = 'Admin';
        }
        else{
            $user = User::find(auth::user()->id);
            $fullNames = $user->first_name;
        }
        return array
        (
            'error' => false,
            'response' => true,
            'message' => 'Success',
            'user_role'=> $userrole_id,
            'fullNames'=>$fullNames
        );
    }

    public function getUsersInfo()
    {
        $user_filter_clause = null;
        $searchValue = null;
        $totalRecords = User::buildUserQuery(User::$filteredTotal_number, null, null);
        ## Total number of record with filtering
        $totalRecordwithFilter = User::buildUserQuery(User::$filteredTotal_number, $searchValue, null);
        ## Fetch records
        $data = User::buildUserQuery(User::$strUserQuery, $searchValue, $user_filter_clause);

        foreach($totalRecordwithFilter as $value){
            $totalRecordwithFilter = $value->allcount;
        }
        return array
        (
            'error' => false,
            'response' => true,
            'data'=>$data
        );
    }

    public function edit(Request $request)
    {
        $searchValue = null;
        $user_filter_clause = '';
        $user_filter_clause .= " AND u.id = ". $request->id;
        $user_record = User::buildUserQuery(User::$strUserQuery, $searchValue, $user_filter_clause);
        return $user_record;
    }

    public function update(Request $request)
    {
        $users = User::updateUser($request);

        $this->mail->confirm_regi();  //Confirm registration
        return $users;
    }

    public function getRoles()
    {
        $roles = Role::all();

        return response()->json([
            'userRole' => $roles,
        ]);
    }
}
