<?php
namespace App\Http\Controllers;
use App\Models\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    public function index()
    {
        $member_filter_clause = null;
        $searchValue = null;
        $totalRecords = Member::buildMemberQuery(Member::$filteredTotal_number, null, null);
        ## Total number of record with filtering
        $totalRecordwithFilter = Member::buildMemberQuery(Member::$filteredTotal_number, $searchValue, null);
        ## Fetch records
        $data = Member::buildMemberQuery(Member::$strMemberQuery, $searchValue, 
            $member_filter_clause);
        foreach($totalRecordwithFilter as $value){
            $totalRecordwithFilter = $value->allcount;
        }

        return array
        (
            'error' => false,
            'response' => true,
            'data'=>$data
        );
    }

    public function show(Request $request)
    {
        $searchValue = null;
        $member_filter_clause = '';
        $member_filter_clause .= " AND m.email = '".$request->email."'";
        $member_record = Member::buildMemberQuery(Member::$strMemberQuery, $searchValue, $member_filter_clause);
        return $member_record;
    }

    public function edit(Request $request)
    {
        //logger($request);
        $searchValue = null;
        $member_filter_clause = '';
        $member_filter_clause .= " AND m.id = ". $request->id;
        $member_record = Member::buildMemberQuery(Member::$strMemberQuery, $searchValue, $member_filter_clause);
        return $member_record;
    }

    public function update(Request $request)
    {
        if((int)$request->id > 0){
            $member = Member::find((int)$request->id);
        }else{
            $member = new Member;      
        }
        $member->first_name = $request->first_name;
        $member->last_name = $request->last_name;
        $member->email = $request->email;
        $member->cell_phone = $request->cell_phone;
        $member->active = $request->active;
        $member->start_date = $request->start_date;
        $member->id_number = $request->id_number;
        $member->gender_cat = $request->gender_cat;
        $member->race_cat = $request->race_cat;
        $member->save();
        return $member;
    }
}
