<?php
namespace App\Models;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use App\Models\UserRole;
use Illuminate\Database\Eloquent\Model;

class User extends Authenticatable
{
    protected $table = 'users';

    public static function buildUserQuery($userQuery, $searchValue, $user_filter_clause)
    {
        ## Search
        $searchQuery = " "; 
        return $userRecord = DB::select(DB::raw($userQuery . $searchQuery . 
        	$user_filter_clause));
    }

    public static $strUserQuery = "SELECT u.*, ur.role_id, ur.id, r.name as role_name
        FROM users as u LEFT JOIN user_roles as ur ON ur.user_id = u.id
        LEFT JOIN roles as r ON r.id = ur.role_id
        WHERE 1 ";

    public static $filteredTotal_number = "select count(*) as allcount
                                    FROM users as u 
									WHERE 1 ";

    public static function updateUser($data)
    {
        if((int)$data->id > 0)
        {
            $user = User::find((int)$data->id);
            $user_role_id = UserRole::where('user_id',(int)$data->id)->pluck('id')[0];
            $user_role = UserRole::find($user_role_id);
        }else{
            $user = new User;    
            $user_role = new UserRole();
        }

        $user->first_name = $data->first_name;
        $user->last_name = $data->last_name;
        $user->email = $data->email;
        $user->username = $data->username;
        $user->active = $data->active;
        $user->password = bcrypt($data->password);
        $user->save();
        $id  = $user->id;
        //
        $user_role->user_id = (int)$id;
        $user_role->role_id = (int)$data->role_id;
        $user_role->save();
        return $user;
    }


}