<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Member extends Model
{
    use HasFactory;

    public static function buildMemberQuery($memberQuery, $searchValue, 
    	$member_filter_clause)
    {
        ## Search
        $searchQuery = " ";
        return $memberRecord = DB::select(DB::raw($memberQuery . $searchQuery . 
        	$member_filter_clause));
    }

    public static $strMemberQuery = "SELECT m.*, g.name as gender_name, 
					    		r.name as race_name, m.id as member_id 
								FROM members as m 
								LEFT JOIN races as r ON r.id = m.race_cat
								LEFT JOIN genders as g ON g.id = m.gender_cat  WHERE 1 ";

    public static $filteredTotal_number = "select count(*) as allcount
                                    FROM members as m 
								LEFT JOIN races as r ON r.id = m.race_cat
								LEFT JOIN genders as g ON g.id = m.gender_cat 
								WHERE 1 ";
}
