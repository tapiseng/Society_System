<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Payment extends Model
{
    use HasFactory;

    public static function buildPaymentQuery($paymentQuery, $searchValue, $payment_filter_clause)
    {
        ## Search
        $searchQuery = " ";     
        return $paymentRecord = DB::select(DB::raw($paymentQuery . $searchQuery . 
        	$payment_filter_clause));
    }

    public static $strPaymentQuery = "SELECT p.*, 
    p.id as payment_id, o.name  as payment_name, m.first_name, m.last_name, s.name as service_name, m.email, m.id_number
		FROM payments as p
		LEFT JOIN members as m ON m.id = p.member_id
		LEFT JOIN services as s ON s.id = p.service_id
		LEFT JOIN payment_options as o ON o.id = p.option_id
		WHERE 1 ";

    public static $filteredTotal_number = "select count(*) as allcount
            FROM payments as p
		LEFT JOIN members as m ON m.id = p.member_id
		LEFT JOIN services as s ON s.id = p.service_id
		LEFT JOIN payment_options as o ON o.id = p.option_id
		WHERE 1 ";

    public static function updateUser($data)
    {
        if((int)$data->id > 0){
            $user = User::find((int)$data->id);
            $user_role_id = UserRole::where('user_id',(int)$data->id)->pluck('id')[0];
            $user_role = UserRole::find($user_role_id);
        }else{
            $user = new User;    
            $user_role = new UserRole();
        }

        $user->first_name = $data->first_name;
        $user->last_name = $data->last_name;
        $user->email = $data->email;
        $user->username = $data->username;
        $user->active = $data->active;
        $user->password = bcrypt($data->password);
        $user->save();
        $id  = $user->id;
        //
        $user_role->user_id = (int)$id;
        $user_role->role_id = (int)$data->role_id;
        $user_role->save();
        return $user;
    }
}
